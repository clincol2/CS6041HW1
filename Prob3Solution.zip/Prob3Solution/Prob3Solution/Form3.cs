﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prob3Solution
{
    public partial class Form3 : Form
    {
        public static string userInput = "";
        public static int inputLen;

        public static int stackCounter;
        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            userInput = userInputBox.Text;


            if (stringIsValid(userInput))
            {
                MessageBox.Show("The string " + userInput + " is accepted for 0^n1^n");
            }
            else
            {
                MessageBox.Show("The string " + userInput + " is rejected for 0^n1^n");
            }
        }
        public bool stringIsValid(string w)
        {
            bool verdict = false;
            char[] arrayVersionOfW = w.ToCharArray();

            if ((w.Length % 2) == 1)
            {
                //it's an odd number, so it can't be 0n1n
                verdict = false;
                return verdict;
            }
            int halfLen = (w.Length) / 2;


            for (int i = 0; i < w.Length; i++)
            {
                string s = arrayVersionOfW[i].ToString();
                if (String.Equals("0", s))
                {
                    stackCounter++;
                }
                else
                {
                    stackCounter--;
                }
            }
            if (stackCounter == 0)
            {
                verdict = true;
            }
            else
            {
                verdict = false;
            }

            return verdict;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form4 form4 = new Form4();
            form4.Show();
        }
    }
}
