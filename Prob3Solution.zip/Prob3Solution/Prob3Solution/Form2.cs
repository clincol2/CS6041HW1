﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prob3Solution
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string pattern = "\\W";
            string input = textBox1.Text;
            string data = Regex.Replace(input.ToLower(), pattern, String.Empty);

            if (data == ReverseString(data))
            {
                MessageBox.Show("The string " + input + " is a palindrome.");
            }
            else
            {
                MessageBox.Show("The string " + input + " is not a palindrome.");
            }
        }



        public static string ReverseString(string s)
        {
            char[] arr = s.ToCharArray();
            Array.Reverse(arr);
            return new string(arr);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form4 form4 = new Form4();
            form4.Show();
        }
    }



}
