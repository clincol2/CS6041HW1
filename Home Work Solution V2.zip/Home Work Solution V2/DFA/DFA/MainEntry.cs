﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using H1 = HW1_prob2;
using H2 = HW1_prob3;

namespace DFA
{
    public partial class MainEntry : Form
    {
        public MainEntry()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 assign1 = new Form1();
            assign1.ShowDialog();
            //System.Diagnostics.Process.Start(Application.StartupPath.ToString() + @"\DFA.exe");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            H1.Form1 assign2 = new HW1_prob2.Form1();
            assign2.ShowDialog();
           // System.Diagnostics.Process.Start(Application.StartupPath.ToString() + @"\HW1_prob2.exe");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            H2.Form1 assign3 = new H2.Form1();
            assign3.ShowDialog();
           // System.Diagnostics.Process.Start(Application.StartupPath.ToString() + @"\HW1_prob3.exe");
        }
    }
}
